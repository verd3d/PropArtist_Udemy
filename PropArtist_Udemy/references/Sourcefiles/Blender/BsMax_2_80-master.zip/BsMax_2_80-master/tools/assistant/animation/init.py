from .between import *

def animation_cls(register, pref):
	between_cls(register)

__all__ = ["animation_cls"]