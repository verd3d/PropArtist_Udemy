from .fonts import *

def font_cls(register, pref):
	fonts_cls(register)

__all__ = ["font_cls"]