from .targetlight import *

def ligth_cls(register, pref):
	targetlight_cls(register)

__all__ = ["ligth_cls"]